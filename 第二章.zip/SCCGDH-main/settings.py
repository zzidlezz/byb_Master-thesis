import logging
import time
import os
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--dataname', type=str, default='flickr', help='Dataset name: flickr/coco/nuswide')
parser.add_argument('--bits', type=int, default=128, help='16/32/64/128')
args = parser.parse_args()

if args.dataname == 'flickr':
    DIR = '../Data/raw_mir.mat'
elif args.dataname == 'nuswide':
    DIR = '../Data/raw_nus.mat'
elif args.dataname == 'coco':
    DIR = '../Data/raw_coco.mat'  
else:
    print('Dataname Error!')
    DIR = ''

DATASET_NAME = args.dataname
CODE_LEN = args.bits 
FLAG_savecode = False


LABEL_DIM = 24    #flickr 24 nuswide 21 coco 80
NUM_EPOCH = 40
LR_IMG = 0.001
LR_TXT = 0.01
EVAL_INTERVAL = 20
BATCH_SIZE = 16
MOMENTUM = 0.9
WEIGHT_DECAY = 5e-4
NUM_WORKERS = 0
EPOCH_INTERVAL = 2

# MODEL_DIR = './checkpoint'
EVAL = False # EVAL = True: just test, EVAL = False: train and eval

logger = logging.getLogger('train')
logger.setLevel(logging.INFO)
now = time.strftime("%Y%m%d%H%M%S",time.localtime(time.time()))
log_name = now + '_log.txt'
log_dir = './log'
if not os.path.exists(log_dir):
    os.makedirs(log_dir)
txt_log = logging.FileHandler(os.path.join(log_dir, log_name))
txt_log.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
txt_log.setFormatter(formatter)
logger.addHandler(txt_log)

stream_log = logging.StreamHandler()
stream_log.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
stream_log.setFormatter(formatter)
logger.addHandler(stream_log)


logger.info('--------------------------settings--------------------------')
logger.info('EVAL = %s' % EVAL)
logger.info('DATASET_NAME = %s' % DATASET_NAME)
logger.info('NUM_EPOCH = %d' % NUM_EPOCH)
logger.info('LR_IMG = %.4f' % LR_IMG)
logger.info('LR_TXT = %.4f' % LR_TXT)
logger.info('BATCH_SIZE = %d' % BATCH_SIZE)
logger.info('CODE_LEN = %d' % CODE_LEN)
logger.info('MOMENTUM = %.4f' % MOMENTUM)
logger.info('WEIGHT_DECAY = %.4f' % WEIGHT_DECAY)
logger.info('NUM_WORKERS = %d' % NUM_WORKERS)
logger.info('EPOCH_INTERVAL = %d' % EPOCH_INTERVAL)
logger.info('EVAL_INTERVAL = %d' % EVAL_INTERVAL)
logger.info('--------------------------------------------------------------------')
