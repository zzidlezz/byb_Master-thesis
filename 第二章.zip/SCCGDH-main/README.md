# SCCGDH
The source code of “SCCGDH” 
# Datasets
We used three cross-modal datasets for experiments.datasets are available by the following link:
链接：https://pan.baidu.com/s/1OxiGSMtS0IVF6WRyorr9og 
提取码：re1r 



