The source code of "Cross-modal Deep Hashing with Ranking Learning for Noisy Labels"

Datasets：链接：https://pan.baidu.com/s/1EKhCw5H9FdLnNcatdo0iMw 
提取码：nsbp 
